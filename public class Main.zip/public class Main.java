public class Main {
    import javax.swing.JOptionPane;

    public class Main {
        public static void main(String[] args) {
            // Initialize user (replace with actual first/last name)
            Login user = new Login("John", "Doe");
    
            // Registration Phase
            String username = JOptionPane.showInputDialog("Enter username (must contain '_' and be ≤5 chars):");
            String password = JOptionPane.showInputDialog("Enter password (≥8 chars, with 1 capital, 1 number, 1 special char):");
            String cellphone = JOptionPane.showInputDialog("Enter cellphone (e.g., +27831234567):");
    
            String regResult = user.registerUser(username, password, cellphone);
            JOptionPane.showMessageDialog(null, regResult);
    
            // Login Phase
            String loginUser = JOptionPane.showInputDialog("Login - Enter username:");
            String loginPass = JOptionPane.showInputDialog("Login - Enter password:");
    
            boolean loginStatus = user.loginUser(loginUser, loginPass);
            String loginResult = user.returnLoginStatus(loginStatus);
            JOptionPane.showMessageDialog(null, loginResult);
        }
    }  
}
