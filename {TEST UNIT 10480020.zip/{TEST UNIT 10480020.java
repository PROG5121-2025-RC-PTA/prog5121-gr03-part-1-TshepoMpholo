public class Main {TEST UNIT
    import org.junit.Test;
import static org.junit.Assert.*;

public class LoginTest {
    @Test
    public void testValidUsername() {
        Login login = new Login("Test", "User");
        assertTrue(login.checkUserName("kyl_1"));  // Valid
        assertFalse(login.checkUserName("kyle"));  // No underscore
        assertFalse(login.checkUserName("user_name"));  // Too long
    }

    @Test
    public void testPasswordComplexity() {
        Login login = new Login("Test", "User");
        assertTrue(login.checkPasswordComplexity("Pass@123"));  // Valid
        assertFalse(login.checkPasswordComplexity("password"));  // No caps/numbers
        assertFalse(login.checkPasswordComplexity("P@ss"));     // Too short
    }

    @Test
    public void testCellphoneValidation() {
        Login login = new Login("Test", "User");
        assertTrue(login.checkCellPhoneNumber("+27831234567"));  // Valid
        assertFalse(login.checkCellPhoneNumber("0831234567"));   // No +
        assertFalse(login.checkCellPhoneNumber("+27123"));       // Too short
    }

    @Test
    public void testRegistration() {
        Login login = new Login("Test", "User");
        String result = login.registerUser("kyl_1", "Pass@123", "+27831234567");
        assertTrue(result.contains("Registration successful"));  // All valid
    }

    @Test
    public void testLogin() {
        Login login = new Login("Test", "User");
        login.registerUser("kyl_1", "Pass@123", "+27831234567");
        assertTrue(login.loginUser("kyl_1", "Pass@123"));   // Correct credentials
        assertFalse(login.loginUser("kyl_1", "wrong"));     // Wrong password
    }
}
}
