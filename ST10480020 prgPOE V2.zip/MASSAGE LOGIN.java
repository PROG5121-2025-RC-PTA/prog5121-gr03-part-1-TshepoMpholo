import javax.swing.JOptionPane;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

public class Message {
    private ArrayList<String> sentMessages = new ArrayList<>();
    private ArrayList<String> disregardedMessages = new ArrayList<>();
    private ArrayList<String> storedMessages = new ArrayList<>();
    private ArrayList<String> messageHashes = new ArrayList<>();
    private ArrayList<String> messageIDs = new ArrayList<>();
    private int totalMessages = 0;

    // Method to check message length
    public String checkMessageLength(String message) {
        if (message.length() > 250) {
            int excess = message.length() - 250;
            return "Message exceeds 250 characters by " + excess + ", please reduce size.";
        }
        return "Message ready to send.";
    }

    // Method to check recipient cell number format (reusing from Login class)
    public boolean checkRecipientCell(String cellNumber) {
        return cellNumber.matches("^\\+\\d{1,3}\\d{9}$");
    }

    // Method to generate a random 10-digit message ID
    public String generateMessageID() {
        Random random = new Random();
        long id = 1000000000L + random.nextInt(900000000);
        return String.valueOf(id);
    }

    // Method to create message hash
    public String createMessageHash(String messageID, int messageNumber, String message) {
        String[] words = message.split(" ");
        String firstWord = words.length > 0 ? words[0] : "";
        String lastWord = words.length > 1 ? words[words.length - 1] : firstWord;
        
        String hash = messageID.substring(0, 2) + ":" + messageNumber + ":" + 
                     firstWord.toUpperCase() + lastWord.toUpperCase();
        return hash;
    }

    // Method to handle sending a message
    public String sendMessage(String recipient, String messageText) {
        // Generate message details
        String messageID = generateMessageID();
        totalMessages++;
        String messageHash = createMessageHash(messageID, totalMessages, messageText);
        
        // Store message details
        messageIDs.add(messageID);
        messageHashes.add(messageHash);
        
        // Create message object
        JSONObject messageObj = new JSONObject();
        messageObj.put("messageID", messageID);
        messageObj.put("messageHash", messageHash);
        messageObj.put("recipient", recipient);
        messageObj.put("message", messageText);
        messageObj.put("status", "sent");
        
        // Add to sent messages
        sentMessages.add(messageObj.toString());
        
        // Return success message with details
        return "Message sent successfully.\n" +
               "Message ID: " + messageID + "\n" +
               "Message Hash: " + messageHash + "\n" +
               "Recipient: " + recipient + "\n" +
               "Message: " + messageText;
    }

    // Method to store message in JSON file (using ChatGPT for reference)
    public void storeMessageToJSON(String recipient, String messageText, String action) {
        try {
            // Create message object
            JSONObject messageObj = new JSONObject();
            messageObj.put("messageID", generateMessageID());
            messageObj.put("recipient", recipient);
            messageObj.put("message", messageText);
            messageObj.put("status", action.equals("store") ? "stored" : "disregarded");
            
            // Add to appropriate list
            if (action.equals("store")) {
                storedMessages.add(messageObj.toString());
            } else {
                disregardedMessages.add(messageObj.toString());
            }
            
            // Write to JSON file
            JSONArray jsonArray = new JSONArray();
            for (String msg : sentMessages) {
                jsonArray.put(new JSONObject(msg));
            }
            for (String msg : storedMessages) {
                jsonArray.put(new JSONObject(msg));
            }
            for (String msg : disregardedMessages) {
                jsonArray.put(new JSONObject(msg));
            }
            
            FileWriter file = new FileWriter("messages.json");
            file.write(jsonArray.toString(4)); // 4 spaces for indentation
            file.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Method to display all sent messages
    public String printMessages() {
        StringBuilder sb = new StringBuilder();
        sb.append("=== Sent Messages ===\n");
        for (String msg : sentMessages) {
            JSONObject obj = new JSONObject(msg);
            sb.append("ID: ").append(obj.getString("messageID")).append("\n");
            sb.append("Hash: ").append(obj.getString("messageHash")).append("\n");
            sb.append("Recipient: ").append(obj.getString("recipient")).append("\n");
            sb.append("Message: ").append(obj.getString("message")).append("\n\n");
        }
        return sb.toString();
    }

    // Method to return total number of messages sent
    public int returnTotalMessages() {
        return totalMessages;
    }
}