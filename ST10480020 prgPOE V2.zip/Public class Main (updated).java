import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        // Initialize user (replace with actual first/last name)
        Login user = new Login("John", "Doe");
        
        // Registration Phase
        String username = JOptionPane.showInputDialog("Enter username (must contain '_' and be ≤5 chars):");
        String password = JOptionPane.showInputDialog("Enter password (≥8 chars, with 1 capital, 1 number, 1 special char):");
        String cellphone = JOptionPane.showInputDialog("Enter cellphone (e.g., +27831234567):");
        
        String regResult = user.registerUser(username, password, cellphone);
        JOptionPane.showMessageDialog(null, regResult);
        
        // Login Phase
        String loginUser = JOptionPane.showInputDialog("Login - Enter username:");
        String loginPass = JOptionPane.showInputDialog("Login - Enter password:");
        
        boolean loginStatus = user.loginUser(loginUser, loginPass);
        String loginResult = user.returnLoginStatus(loginStatus);
        JOptionPane.showMessageDialog(null, loginResult);
        
        // Only proceed to messaging if login was successful
        if (loginStatus) {
            Message messageSystem = new Message();
            boolean running = true;
            
            while (running) {
                String option = JOptionPane.showInputDialog(
                    "Welcome to QuickChat\n" +
                    "1) Send Messages\n" +
                    "2) Show recently sent messages\n" +
                    "3) Quit\n" +
                    "Enter your choice (1-3):"
                );
                
                switch (option) {
                    case "1":
                        sendMessages(messageSystem);
                        break;
                    case "2":
                        JOptionPane.showMessageDialog(null, "Coming Soon.");
                        break;
                    case "3":
                        running = false;
                        JOptionPane.showMessageDialog(null, 
                            "Total messages sent: " + messageSystem.returnTotalMessages() + 
                            "\nGoodbye!");
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Invalid option. Please try again.");
                }
            }
        }
    }
    
    private static void sendMessages(Message messageSystem) {
        String numMessagesStr = JOptionPane.showInputDialog("How many messages would you like to send?");
        int numMessages;
        
        try {
            numMessages = Integer.parseInt(numMessagesStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Please enter a valid number.");
            return;
        }
        
        for (int i = 0; i < numMessages; i++) {
            String recipient = JOptionPane.showInputDialog("Enter recipient's cell number (e.g., +27831234567):");
            
            // Validate recipient number
            if (!messageSystem.checkRecipientCell(recipient)) {
                JOptionPane.showMessageDialog(null, 
                    "Cell phone number is incorrectly formatted or does not contain an international code.");
                continue;
            }
            
            String messageText = JOptionPane.showInputDialog("Enter your message (max 250 chars):");
            
            // Validate message length
            String lengthCheck = messageSystem.checkMessageLength(messageText);
            if (!lengthCheck.equals("Message ready to send.")) {
                JOptionPane.showMessageDialog(null, lengthCheck);
                continue;
            }
            
            // Ask user what to do with the message
            String action = JOptionPane.showInputDialog(
                "Message details:\n" +
                "Recipient: " + recipient + "\n" +
                "Message: " + messageText + "\n\n" +
                "Choose action:\n" +
                "1) Send Message\n" +
                "2) Disregard Message\n" +
                "3) Store Message to send later\n" +
                "Enter your choice (1-3):"
            );
            
            switch (action) {
                case "1":
                    String result = messageSystem.sendMessage(recipient, messageText);
                    JOptionPane.showMessageDialog(null, result);
                    break;
                case "2":
                    messageSystem.storeMessageToJSON(recipient, messageText, "disregard");
                    JOptionPane.showMessageDialog(null, "Message disregarded.");
                    break;
                case "3":
                    messageSystem.storeMessageToJSON(recipient, messageText, "store");
                    JOptionPane.showMessageDialog(null, "Message stored for later.");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid option. Message not sent.");
            }
        }
        
        // Show all sent messages after sending batch
        JOptionPane.showMessageDialog(null, messageSystem.printMessages());
    }
}