import org.junit.Test;
import static org.junit.Assert.*;

public class MessageTest {
    @Test
    public void testMessageLengthValidation() {
        Message message = new Message();
        
        // Test valid message length
        assertEquals("Message ready to send.", 
            message.checkMessageLength("Short message"));
            
        // Test invalid message length
        String longMessage = "This is a very long message that exceeds the 250 character limit. " +
            "This is a very long message that exceeds the 250 character limit. " +
            "This is a very long message that exceeds the 250 character limit. " +
            "This is a very long message that exceeds the 250 character limit. " +
            "This is a very long message that exceeds the 250 character limit.";
        assertTrue(message.checkMessageLength(longMessage).contains("Message exceeds 250 characters"));
    }
    
    @Test
    public void testRecipientCellValidation() {
        Message message = new Message();
        
        // Test valid cell numbers
        assertTrue(message.checkRecipientCell("+27831234567"));
        assertTrue(message.checkRecipientCell("+27123456789"));
        
        // Test invalid cell numbers
        assertFalse(message.checkRecipientCell("0831234567")); // No international code
        assertFalse(message.checkRecipientCell("+27123")); // Too short
        assertFalse(message.checkRecipientCell("27831234567")); // Missing +
    }
    
    @Test
    public void testMessageHashCreation() {
        Message message = new Message();
        
        // Test hash creation
        String hash = message.createMessageHash("1234567890", 1, "Hello world");
        assertEquals("12:1:HELLOWORLD", hash);
        
        hash = message.createMessageHash("9876543210", 2, "Quick brown fox");
        assertEquals("98:2:QUICKFOX", hash);
    }
    
    @Test
    public void testMessageSending() {
        Message message = new Message();
        
        // Test sending a message
        String result = message.sendMessage("+27831234567", "Test message");
        assertTrue(result.contains("Message sent successfully"));
        assertEquals(1, message.returnTotalMessages());
        
        // Test message details storage
        assertFalse(message.printMessages().isEmpty());
    }
}