import java.util.Scanner;

public class Login {
    private String username;
    private String password;
    private String cellPhoneNumber;
    private String firstName;
    private String lastName;

    // Method to check username format
    public boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    // Method to check password complexity
    public boolean checkPasswordComplexity(String password) {
        boolean hasUpperCase = !password.equals(password.toLowerCase());
        boolean hasNumber = password.matches(".\\d.");
        boolean hasSpecialChar = !password.matches("[A-Za-z0-9]*");
        return password.length() >= 8 && hasUpperCase && hasNumber && hasSpecialChar;
    }

    // Method to check cell phone number format (AI-generated regex)
    public boolean checkCellPhoneNumber(String cellPhoneNumber) {
        // Regex generated with ChatGPT (https://chat.openai.com/)
        // Checks for international code (e.g., +27 for South Africa) followed by 9 digits
        return cellPhoneNumber.matches("^\\+\\d{1,3}\\d{9}$");
    }

    // Method to register a user
    public String registerUser(String username, String password, String cellPhoneNumber) {
        StringBuilder message = new StringBuilder();

        if (!checkUserName(username)) {
            message.append("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.\n");
        } else {
            message.append("Username successfully captured.\n");
        }

        if (!checkPasswordComplexity(password)) {
            message.append("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.\n");
        } else {
            message.append("Password successfully captured.\n");
        }

        if (!checkCellPhoneNumber(cellPhoneNumber)) {
            message.append("Cell phone number is incorrectly formatted or does not contain an international code.\n");
        } else {
            message.append("Cell phone number successfully added.\n");
        }

        // Only store details if all validations pass
        if (checkUserName(username) && checkPasswordComplexity(password) && checkCellPhoneNumber(cellPhoneNumber)) {
            this.username = username;
            this.password = password;
            this.cellPhoneNumber = cellPhoneNumber;
            this.firstName = "User";  // Placeholder (can be extended)
            this.lastName = "Test";   // Placeholder (can be extended)
            message.append("User registered successfully.");
        }

        return message.toString();
    }

    // Method to verify login
    public boolean loginUser(String username, String password) {
        return this.username != null && this.username.equals(username) && this.password.equals(password);
    }

    // Method to return login status message
    public String returnLoginStatus(boolean loginStatus) {
        if (loginStatus) {
            return "Welcome " + firstName + ", " + lastName + ", it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }

    // Main method for testing (optional)
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login loginSystem = new Login();

        System.out.println("=== Registration ===");
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        System.out.print("Enter cell phone number (e.g., +27839284756): ");
        String cellPhoneNumber = scanner.nextLine();

        String registrationMessage = loginSystem.registerUser(username, password, cellPhoneNumber);
        System.out.println(registrationMessage);

        System.out.println("\n=== Login ===");
        System.out.print("Enter username: ");
        String loginUsername = scanner.nextLine();
        System.out.print("Enter password: ");
        String loginPassword = scanner.nextLine();

        boolean loginSuccess = loginSystem.loginUser(loginUsername, loginPassword);
        System.out.println(loginSystem.returnLoginStatus(loginSuccess));

        scanner.close();
    }
}
